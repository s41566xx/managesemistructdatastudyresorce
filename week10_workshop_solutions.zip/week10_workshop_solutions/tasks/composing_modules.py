def build_expander_prompt(query: str) -> tuple[str, str]:
    """Build two prompt strings from the original query string.

    Return (system_prompt, user_prompt). run_expander sends them to the model
    and reads its JSON variants. This function does not call the API.
    """
    system_prompt = """
You are a query-rewriting assistant for coffee shop review retrieval.
Rewrite the user query into 3 short variants written the way reviewers speak about waiting time and service speed. Cover the whole topic, both quick and slow experiences, using concrete words such as: quick, fast, prompt, served right away, average timing, slow, waited, long queue, delayed, took too long.
Keep any cafe names. Use plain declarative phrases, not questions.
Return only one valid JSON object with exactly this shape:
{"variants": ["variant 1", "variant 2", "variant 3"]}
Do not include explanation, markdown, or extra keys.
""".strip()
    user_prompt = f"Original query:\n{query}"
    return system_prompt, user_prompt


def merge_candidates(
    result_lists: list[list[dict]],
    top_k: int = 10,
) -> list[dict]:
    """Fuse ranked result lists using rrf_k = 60.

    Input example, with one ranked list per query:
        [[{"rank": 1, "id": "R001", "score": 0.8, "content": "Slow service."}],
         [{"rank": 1, "id": "R289", "score": 0.7, "content": "Quick service."}]]
    Return one flat list of records with rank, id, score and content.
    For the input above, an output record is:
        {"rank": 1, "id": "R001", "score": 1 / 61, "content": "Slow service."}
    Sum 1 / (60 + rank) across lists, keep unique IDs, then assign new ranks.
    top_k limits the number of returned reviews.
    """
    # Raw scores from different query lists can have different scales. RRF instead
    # combines rank positions, so one document can receive support from many lists.
    rrf_k = 60
    # A new document starts with score 0. The dictionaries merge entries by ID.
    scores = {}
    docs = {}

    # Accumulate one rank-based contribution for every document occurrence.
    for rows in result_lists:
        for rank, row in enumerate(rows, start=1):
            doc_id = str(row["id"])
            scores[doc_id] = scores.get(doc_id, 0.0) + 1.0 / (rrf_k + rank)
            # Preserve one source row so the merged result can return content.
            docs[doc_id] = row

    # Sort by fused score and assign a new rank sequence for the module output.
    ordered_ids = sorted(scores, key=scores.get, reverse=True)[:top_k]
    # Attach the source text and assign new ranks to the merged results.
    results = []
    for rank, doc_id in enumerate(ordered_ids, start=1):
        results.append({
            "rank": rank,
            "id": doc_id,
            "score": float(scores[doc_id]),
            "content": docs[doc_id]["content"],
        })
    return results
